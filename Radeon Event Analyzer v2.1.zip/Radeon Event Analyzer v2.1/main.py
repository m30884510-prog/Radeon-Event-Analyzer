import tkinter as tk
import subprocess
import json
import re
from tkinter import *

amd_gpu_error_keywords = ["amdwddmg", "amdkmdag", "amdkmdap", "amdppm", "atikmdag", "atikmpag", "amdacp", "amdacpbus", "amdvlk", "Advanced Micro Devices, Inc. Display Driver", "AMD Radeon", "Radeon Graphics", "AMD Display Driver", "AMD Graphics Driver", "AMD GPU", "AMD Software: Adrenalin Edition", "Radeon Software", "Adrenalin", "Display Driver Update", "Graphics Driver Update", "GPU driver update", "GPU driver installation", "GPU driver uninstall", "GPU driver rollback", "GPU driver migration", "GPU driver initialization", "GPU driver recovery", "GPU driver reset", "GPU driver crash", "GPU driver timeout", "GPU driver failure", "GPU driver error", "GPU driver stopped responding", "display driver stopped responding", "display driver has stopped responding", "display driver stopped responding and has recovered", "graphics driver stopped responding", "graphics driver reset", "graphics driver crash", "graphics driver timeout", "graphics driver failure", "VIDEO_TDR_FAILURE", "VIDEO_TDR_TIMEOUT_DETECTED", "VIDEO_ENGINE_TIMEOUT_DETECTED", "VIDEO_SCHEDULER_INTERNAL_ERROR", "VIDEO_DXGKRNL_FATAL_ERROR", "VIDEO_DEVICE_HUNG", "VIDEO_DRIVER_INIT_FAILURE", "VIDEO_MEMORY_MANAGEMENT_INTERNAL", "TDR", "TdrDelay", "TdrDdiDelay", "LiveKernelEvent 117", "LiveKernelEvent 141", "LiveKernelEvent 142", "LiveKernelEvent 144", "LiveKernelEvent 1a8", "LiveKernelEvent 193", "0x117", "0x141", "0x142", "0x116", "0x119", "0x10E", "dxgkrnl", "dxgmms2", "dxgmms", "DXGI_ERROR_DEVICE_REMOVED", "DXGI_ERROR_DEVICE_HUNG", "DXGI_ERROR_DEVICE_RESET", "DXGI_ERROR_DRIVER_INTERNAL_ERROR", "DXGI_ERROR_DEVICE_CREATION_FAILED", "D3D_DEVICE_REMOVED", "D3D_DEVICE_HUNG", "D3D_DEVICE_RESET", "D3D11_DEVICE_REMOVED", "D3D12_DEVICE_REMOVED", "D3D12_DEVICE_HUNG", "D3D12_DEVICE_RESET", "DirectX error", "Direct3D error", "D3D error", "device removed", "device hung", "device reset", "device lost", "VK_ERROR_DEVICE_LOST", "VK_ERROR_OUT_OF_DEVICE_MEMORY", "VK_ERROR_DEVICE_MEMORY", "VK_ERROR_INITIALIZATION_FAILED", "Vulkan device lost", "OpenGL context lost", "GL_CONTEXT_LOST", "GL_OUT_OF_MEMORY", "CL_DEVICE_NOT_AVAILABLE", "CL_OUT_OF_RESOURCES", "UVD", "VCE", "VCN", "SDMA", "GFX timeout", "GFX error", "GFX hang", "GFX reset", "GFX fault", "GPU reset", "GPU timeout", "GPU crash", "GPU hang", "GPU fault", "GPU failure", "GPU stopped responding", "GPU not responding", "GPU initialization failed", "GPU device lost", "GPU device reset", "GPU device hung", "GPU memory error", "GPU memory allocation", "GPU memory failure", "GPU memory corruption", "VRAM error", "VRAM allocation", "video memory error", "out of video memory", "graphics memory error", "graphics memory allocation", "graphics device lost", "graphics device reset", "graphics device hung", "graphics initialization failed", "graphics context lost", "graphics resource failure", "graphics engine timeout", "graphics engine reset", "graphics engine failure", "GPU engine timeout", "GPU engine reset", "GPU engine failure", "GPU scheduler", "GPU scheduling", "GPU execution timeout", "GPU command timeout", "GPU fence timeout", "GPU queue timeout", "GPU power state", "GPU thermal", "GPU throttling", "GPU firmware", "GPU DPM", "SMU error", "SMU timeout", "WHEA-Logger", "WHEA", "PCI Express", "PCIe error", "PCIe bus error", "PCIe link error", "PCIe AER", "Advanced Error Reporting", "Corrected Hardware Error", "Uncorrectable Hardware Error", "Bus/Interconnect Error", "Event ID 4101", "Kernel-PnP", "XGpuEjectDialog", "Microsoft.Windows.DriverInstall.DeviceInstall", "Microsoft.Windows.DriverInstall.NewDevInstallDeviceEnd", "Microsoft.Windows.DriverInstall.NewDevInstallDeviceStart", "Driver installation", "driver update", "driver installed", "driver installation failed", "driver install failure", "driver install error", "driver install completed", "driver install started", "driver rollback", "driver migration", "driver removal", "driver uninstallation", "driver package", "DriverProvider", "DriverVersion", "DriverDescription", "DeviceInstanceId", "Display Driver Update"]

def start(cnt):
    result = subprocess.run(["wevtutil", "qe", "system", f"/c:{cnt or 100}", "/rd:true", "/f:text"], capture_output=True, text=True)
    result = result.stdout

    result = split_text(result)
    for i in result[:]:
        values = [v.lower() for v in i.values() if isinstance(v, str)]
        if not any(w in val for w in amd_gpu_error_keywords for val in values):
            result.remove(i)

    with open("data.json", "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

def success_display():
    print("bem bem")
    root = tk.Tk()
    label = tk.Label(root, text="Check the Data.json file to see found events", font=("Arial", 14, "bold"),fg="blue")
    label2 = tk.Label(root, text="file may have empty list ([]) if no problems were found", font=("Arial", 10, "bold"), fg="blue")
    label.pack(pady=10)
    label2.pack(pady=10)
    root.title("success!")
    root.geometry("500x150")


amd_gpu_error_keywords = ["amdwddmg", "amdkmdag", "amdkmdap", "amdppm", "atikmdag", "atikmpag", "amdacp", "amdacpbus", "amdvlk", "Advanced Micro Devices, Inc. Display Driver", "AMD Radeon", "Radeon Graphics", "AMD Display Driver", "AMD Graphics Driver", "AMD GPU", "AMD Software: Adrenalin Edition", "Radeon Software", "Adrenalin", "Display Driver Update", "Graphics Driver Update", "GPU driver update", "GPU driver installation", "GPU driver uninstall", "GPU driver rollback", "GPU driver migration", "GPU driver initialization", "GPU driver recovery", "GPU driver reset", "GPU driver crash", "GPU driver timeout", "GPU driver failure", "GPU driver error", "GPU driver stopped responding", "display driver stopped responding", "display driver has stopped responding", "display driver stopped responding and has recovered", "graphics driver stopped responding", "graphics driver reset", "graphics driver crash", "graphics driver timeout", "graphics driver failure", "VIDEO_TDR_FAILURE", "VIDEO_TDR_TIMEOUT_DETECTED", "VIDEO_ENGINE_TIMEOUT_DETECTED", "VIDEO_SCHEDULER_INTERNAL_ERROR", "VIDEO_DXGKRNL_FATAL_ERROR", "VIDEO_DEVICE_HUNG", "VIDEO_DRIVER_INIT_FAILURE", "VIDEO_MEMORY_MANAGEMENT_INTERNAL", "TDR", "TdrDelay", "TdrDdiDelay", "LiveKernelEvent 117", "LiveKernelEvent 141", "LiveKernelEvent 142", "LiveKernelEvent 144", "LiveKernelEvent 1a8", "LiveKernelEvent 193", "0x117", "0x141", "0x142", "0x116", "0x119", "0x10E", "dxgkrnl", "dxgmms2", "dxgmms", "DXGI_ERROR_DEVICE_REMOVED", "DXGI_ERROR_DEVICE_HUNG", "DXGI_ERROR_DEVICE_RESET", "DXGI_ERROR_DRIVER_INTERNAL_ERROR", "DXGI_ERROR_DEVICE_CREATION_FAILED", "D3D_DEVICE_REMOVED", "D3D_DEVICE_HUNG", "D3D_DEVICE_RESET", "D3D11_DEVICE_REMOVED", "D3D12_DEVICE_REMOVED", "D3D12_DEVICE_HUNG", "D3D12_DEVICE_RESET", "DirectX error", "Direct3D error", "D3D error", "device removed", "device hung", "device reset", "device lost", "VK_ERROR_DEVICE_LOST", "VK_ERROR_OUT_OF_DEVICE_MEMORY", "VK_ERROR_DEVICE_MEMORY", "VK_ERROR_INITIALIZATION_FAILED", "Vulkan device lost", "OpenGL context lost", "GL_CONTEXT_LOST", "GL_OUT_OF_MEMORY", "CL_DEVICE_NOT_AVAILABLE", "CL_OUT_OF_RESOURCES", "UVD", "VCE", "VCN", "SDMA", "GFX timeout", "GFX error", "GFX hang", "GFX reset", "GFX fault", "GPU reset", "GPU timeout", "GPU crash", "GPU hang", "GPU fault", "GPU failure", "GPU stopped responding", "GPU not responding", "GPU initialization failed", "GPU device lost", "GPU device reset", "GPU device hung", "GPU memory error", "GPU memory allocation", "GPU memory failure", "GPU memory corruption", "VRAM error", "VRAM allocation", "video memory error", "out of video memory", "graphics memory error", "graphics memory allocation", "graphics device lost", "graphics device reset", "graphics device hung", "graphics initialization failed", "graphics context lost", "graphics resource failure", "graphics engine timeout", "graphics engine reset", "graphics engine failure", "GPU engine timeout", "GPU engine reset", "GPU engine failure", "GPU scheduler", "GPU scheduling", "GPU execution timeout", "GPU command timeout", "GPU fence timeout", "GPU queue timeout", "GPU power state", "GPU thermal", "GPU throttling", "GPU firmware", "GPU DPM", "SMU error", "SMU timeout", "WHEA-Logger", "WHEA", "PCI Express", "PCIe error", "PCIe bus error", "PCIe link error", "PCIe AER", "Advanced Error Reporting", "Corrected Hardware Error", "Uncorrectable Hardware Error", "Bus/Interconnect Error", "Event ID 4101", "Kernel-PnP", "XGpuEjectDialog", "Microsoft.Windows.DriverInstall.DeviceInstall", "Microsoft.Windows.DriverInstall.NewDevInstallDeviceEnd", "Microsoft.Windows.DriverInstall.NewDevInstallDeviceStart", "Driver installation", "driver update", "driver installed", "driver installation failed", "driver install failure", "driver install error", "driver install completed", "driver install started", "driver rollback", "driver migration", "driver removal", "driver uninstallation", "driver package", "DriverProvider", "DriverVersion", "DriverDescription", "DeviceInstanceId", "Display Driver Update"]

def split_text(text):
    blocks_1 = text.split("Event[")[1:]
    blocks = []
    for i in blocks_1:
        blocks.append("Event[" + i)
    events = []
    for block in blocks:
        match_event = re.search(r'Event ID:\s*(\d+)', block)
        match_date = re.search(r'Date:\s*(.*)', block)
        match_source = re.search(r'Source:\s*(.*)', block)
        match_description = re.search(r'Description:\s*(.*)', block)
        if match_event:
            event_id = match_event.group(1)
        else:
            event_id = "None"
        if match_date:
            event_date = match_date.group(1)
        else:
            event_date = "None"
        if match_source:
            event_source = match_source.group(1)
        else:
            event_source = "None"
        if match_description:
            event_description = match_description.group(1)
        else:
            event_description = "None"
        event = {"id": event_id, "date": event_date, "source": event_source, "description": event_description}
        events.append(event)
    success_display()
    print("bem bem bem")
    return events

root = tk.Tk()
label = tk.Label(root, text="Выберете кол-во проверяемых событий:", font=("Arial", 14, "bold"), fg="blue")
root.title("Radeon Event Analyzer")
root.geometry("400x200")

label.pack(pady=10)
ent = Entry(root, width=20)
ent.pack()
but_1 = Button(text="Начать", width=10, height=2, command=lambda: start(ent.get()))
but_1.place(x=150, y=75)
root.mainloop()

